% ENG1802 Assignment 3 - Question 3 c)
% 
% To test the programs created in questions 3(a) and 3(b) and using actual
% images as inputs as well as validating the results.
% 
% Author: ABBAS ZAHR
% SID   : 500548943
% 
% Start witha clear and blank workspace
clear;
clc;
close all;

% Initialise the Image array and convert to grayscale for easier SSD
% calculation.
image_ArrayRGB = imread('peppers.png');
image_ArrayGray    = double(rgb2gray(image_ArrayRGB)); 

% Create the object array, this will be used to calculate the sum squared
% difference. Convert to grayscale image for easier SSD calculation.
object_ArrayRGB = imread('onion.png');
object_ArrayGray = double(rgb2gray(object_ArrayRGB));
 
% Obtain the size of the image array      
 [image_rows, image_cols, image_colors] = size(image_ArrayGray);
 
% Obtain the size of the object array
 [object_rows, object_cols, object_colors] = size(object_ArrayGray);

% Assign the variable n to the size of the object array, this will make
% the code more concise in the future
 n = size(object_ArrayGray);

 
% The SSD array will be a zero array with the size calculated by the 
% rows/colums of the image matrix subtracted by  the size of the square
% object matrix with 1 added to it.
SSD = zeros(image_rows - n(1) + 1, image_cols - n(2) + 1 );
 
% Obtain the size of the zero SSD matrix
[SSD_rows, SSD_cols] = size(SSD);
 
% Initialise two more variables in which define the boundaries in which the
% loop can slide through the image matrix. 
% 
% Setting these variables will prevent any errors stating that the
% detectected matrices will be out of the image's boundaries.
% 
% n(1) is the no. of rows in the object array
% n(2) is the no. of cols in the object array
 slide_Rows = image_rows - n(1) + 1;   
 slide_Cols = image_cols - n(2) + 1;  
 
% If the size of the object is larger than the size of the image, print a
% message and return the code
 if size(object_ArrayGray) > size(image_ArrayGray)
     fprintf('The template must be smaller than %d x %2d', image_cols, image_rows)
     return
 end 
 
% Loop through the image array
for u = 1: slide_Rows 
    
    for v = 1: slide_Cols 

%       Initialise two variables in which determine the dimensions of the
%       sub-images to be cut form the image array.
        subimage_ArrayRow = u: u + n(1) - 1;
        subimage_ArrayCol = v: v + n(2) - 1;
         
%           Now we define the cutout matrix by subbing the variables above
%           and cropping the image array with these bound aries.
            sub_Image = image_ArrayGray(subimage_ArrayRow, subimage_ArrayCol);
            
%           To calculate the sum square difference, we first create a
%           variable named array_Difference to find the difference between
%           the cropped out array, and the object array
            array_Difference = sub_Image - object_ArrayGray;
            
%           Next, we square each element of the array_Difference
%           array and then calculate the sum of every element in the
%           squared array.
            SSD(u,v) = sum(sum(array_Difference(:).^2));  
    end
end

% We are going to call the function from part b to create a normalised
% SSD matrix. This reduces all the large values from the SSD matrix into
% values from 0 to 1
normalised_SSDmatrix = minmax_norm(SSD);

% Get the size of the normalised_SSDmatrix
[norm_rows, norm_cols] = size(normalised_SSDmatrix);

% Loop through the normalised matrix.
for a = 1: norm_rows
    for b = 1:norm_cols
        
%       Find the location of the element in the normalised SSD matrix that
%       is equal to 0.
        if normalised_SSDmatrix(a,b) == 0
            
%           Assign variables to the location of the lowest SSD value, these
%           will be the minimum points for the cropping dimensions
            xmin = b;
            ymin = a;
        end
    end
end

% Initialise the width and height to be the dimensions of the object
% Array. Subtract 1 from the row and heigh since we are adding the object's
% width and height to a minimum coordinate.
width = object_cols -1;
height = object_rows -1;

% Create an array in which contains the minimum cropping points and the
% desired width/height
crop_dims = [xmin, ymin, width, height];

% Create a new variable cropped_Image that calls the function created in Q1
% of the assignment and set the initial image and the crop dimensions
% array as the function parameters
cropped_Image = image_crop('peppers.png', crop_dims);

% Show the cropped image
imshow(cropped_Image)

% Write the image into a png file
imwrite(cropped_Image, 'azah3521_q3cAnswer.png')

% To verify that both object and crop results are the same, we can use the
% imhist()nfunction to compare the intensity values through a histogram.

% Make a 1x2 subplot and plot the frequency counts for both the onion and
% the cropped image. Each histogram will be labelled appropriately and will
% have different colors

% Plotting the object array
subplot(1,2,1)
freq_onion = imhist(object_ArrayRGB);
bar(freq_onion, 'b')
xlabel('Intensity Values')
ylabel('count')
title('Object')

% Plotting the cropped array
subplot(1,2,2)
freq_crop = imhist(cropped_Image);
bar(freq_crop, 'r')
xlabel('Intensity Values')
ylabel('count')
title('Crop Results')
                         
% By plotting the cropped results and the object array, both histograms
% look identical. To prove that the cropped image is identical to the
% object, we can check each value of the intensity counts and they are both
% identitcal. Additionally, we can calculate the sum square difference of
% the two arrays

% create another array_Difference variable and subtract the object
% array from the cropped image array,
array_Difference2 = cropped_Image - object_ArrayRGB;

% perform the SSD calculation for the array difference
objectcrop_SSD = sum(sum(array_Difference2(:).^2));

% If the SSD calculation gives a value of 0, it means both the object and
% cropped image are identity
% Print a message because why not ;)
if objectcrop_SSD == 0
    disp('yayy they are both identical!!')
else
    disp('its wrong, fix your code!!!')
end 

% % % % % % % % % % % % % % Conclusion % % % % % % % % % % %  % % % % % % %

% To conclude the code written successfully detected and cropped the object
% within the peppers image. This has been proven by plotting the frequency
% counts of both the arrays and proving that the intensity frequencies were
% identitical. Additionally, a second proof was carried out by calculating
% the sum square difference betweent the two arrays and it had given a
% value of 0, which further proves that the output of the code is
% identitcal to the object.
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
