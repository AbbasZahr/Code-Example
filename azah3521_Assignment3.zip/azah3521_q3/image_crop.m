% ENG1802 Assignment 3 - Question 1 a)
% To create an image cropping function that takes an image and cropping
% dimensions as parameters
% 
% Author: ABBAS ZAHR
% 
% function name: image_crop

function new_image = image_crop(x,y)

% By taking the input x, which is a string value that corresponds to the
% name of the image file, this line will read that imagine into the program
pic = imread(x);

% Get the size of the image
[rows, cols, colors] = size(pic);

% Initialise variables for the size of the image
r = rows;
c = cols;

% Take the second input which defines the cropping dimensions. The first
% two elements minX and minY are the spatial coordinates of the starting 
% point of the crop box and the maxX and maxY will be the spatial
% coordinates of the end points of the crop box by adding the width and
% height given.
xmin = y(1);
ymin = y(2);
width = y(3);
height = y(4);
xmax = xmin + width;
ymax = ymin + height;

% Check if the starting points (xmin & ymin) are out of the bounds of the image
% dimensions. If so, the function will print an error which quotes the
% boundaries. The boundaries in the error message will also change
% according to the size of the image passed to the function.
if xmin > cols || ymin > rows
      error('Starting point is out of bounds. xmin must be between 1 to %d. ymin must be between 1 to %2d.', c, r)

% Check if the cropping width and height exceeds the size of the image. If
% so, print an error in which quotes the size of the image and will also
% change according to the size of the image passed to the function.
elseif width > c || height > r
      error('Size of image is %d x %2d. Attempting to crop beyond size of image', r, c)

      
% Check if the sum of the starting points and the width & height (xmax & ymax exceed the size of the image
% If so, print the same message as above where the values change according
% to the size of the image passed to the function.
elseif xmax > c || ymax > r
      error('Size of image is %d x %2d. Attempting to crop beyond size of image', r, c)
      
% If none of the conditions above are satisfied, crop the image
else 
        % Create a new variable named cropped_pic which will 'crop' a section of
        % the initial image according to the cropping coordinates
        cropped_pic = pic(ymin:ymax, xmin: xmax, :);
end 

% Return the cropped image
new_image = cropped_pic;
end 