% ENG1802 Assignment 3 - Question 3 b)
% 
% To test the minmax_norm function.
% 
% Author: ABBAS ZAHR
% SID   : 500548943
% 
% Start witha clear and blank workspace

clear;
clc;
close all;

% Initialise an array containing the same elements given in part b
x = [ 0, 6, 2; 4, 3, 2; 6, 1, 1];

% Create a variable and call the minmax_norm function with x as the input
output_array = minmax_norm(x);

% Display the output array called from the function
disp(output_array)