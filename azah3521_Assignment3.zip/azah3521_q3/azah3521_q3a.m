% ENG1802 Assignment 3 - Question 3 a)
% 
% To write a code to perform the SSD calculation given an image array and
% an object array. This will find the lowest value in the SSD calculation
% and print the location and determines which part of the image matrix
% matches or is similar to the object matrix
% 
% Author: ABBAS ZAHR
% SID   : 500548943  
% 
% Start with a clear workspace and command window
clear;
clc;
close all;

% Initialise the image array by using csvread() function
image_Array = csvread('Q3.txt');

% Create the object array, this will be used to calculate the sum squared
% difference
object_Array = [0 6 2; 4 3 2; 6 1 1];

           
% Obtain the size of the image and object arrays     
[image_rows, image_cols] = size(image_Array);
[Object_rows, Object_cols] = size(object_Array);

% Assign the variable n to the size of the object array, this will make
% the code more concise in the future
n = size(object_Array);
 

% The SSD array will be a zero array with the size calculated by the 
% rows/colums of the image matrix subtracted by  the size of the
% object matrix with 1 added to it.
SSD = zeros(image_rows - n(1) + 1, image_cols - n(2) + 1 );

 
% Obtain the size of the zero SSD matrix
[SSD_rows, SSD_cols] = size(SSD);
 
% Initialise two more variables in which define the boundaries in which the
% loop can slide through the image matrix. 
% 
% Setting these variables will prevent any errors stating that the
% detectected matrices will be out of the image's boundaries.
% 
%  n(1) is the rows of the object array
%  n(2) is the no. of cols of the object array
slide_Rows = image_rows - n(1) + 1;
slide_Cols = image_cols - n(2) + 1;
 

% Loop through the image array
for u = 1: slide_Rows 
    
    for v = 1: slide_Cols 
  
%       Initialise two variables in which determine the dimensions of the
%       sub-images to be cut form the image array.
        image_ArrayRow = u: u + n(1) - 1;
        image_ArrayCol = v: v + n(2) - 1;
         
%           Now we define the cutout matrix by subbing the variables above
%           and cropping the image array with these boundaries.
            sub_Image = image_Array(image_ArrayRow, image_ArrayCol);
            
%           To calculate the sum square difference, we first create a
%           variable named array_Difference to find the difference between
%           the cropped out array, and the object array
            array_Difference = sub_Image - object_Array;
            
%           Next, we square each element of the array_Difference
%           array and then calculate the sum of every element in the
%           squared array.
            SSD_Calculation = sum(array_Difference(:).^2); 
            SSD(u, v) = SSD_Calculation;
          
    end
end

% Now we are going to check for the lowest value in the SSD array by
% looping through it.

% Initialise a minimum value which will intially be the first element of
% the SSD array
minimum_SSDValue = SSD(1,1);
 
%  Loop through the SSD matrix
 for n = 1:2
     for a = 1:SSD_rows
         for b = 1:SSD_cols
             
%            If the current indexed element is less than the intial minimum
%            value and loops the first time, it beomes the new minimum
%            value
             if SSD(a,b) < minimum_SSDValue && n == 1
                 minimum_SSDValue = SSD(a,b);
                 
%            If looped the second time and a new minimum is found, print
%            the location of the final minimum value only.
             elseif SSD(a,b) == minimum_SSDValue && n == 2
                 fprintf('Location of object is at %d,%2d', a,b )

             end
         end
     end
 end 
 
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %  
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 






                

   


 
 
     






