% ENG1802 Assignment 3 - Question 3 b)
% 
% To create a function that takes an array as a parameter and creates a
% 'normalised' output of the array which contains values fwhich range zero
% to 1. Makes locating the lowest SSD value a more effecicent process.
% 
% Author: ABBAS ZAHR

% Create a function named minmax_norm that takes x as a parameter and
% returns a final output
function normalised_array = minmax_norm(x)

% Determine the size of the array passed into the function
[rows, cols] = size(x);

% Create a zero array with the same size as the array passed to the
% function
normalised_array = zeros(size(x));

% Find the maximum and minimum values of the array
minx = min(x,[],'all');
maxx = max(x,[],'all');

% Loop through the zero array created earlier
for r = 1:rows
    for c = 1:cols
        
%       Each element of the normalised array will be determined by the
%       formula given in the question:
% 
%       normalisation  =  value - min
%                       ----------------
%                          max  - min
%       Use this formula and set the current index to the calculated value.
%       Return the normalised array. Round to 2 decimal places
        normalised_array(r,c) = round([(x(r,c)-minx)/(maxx-minx)],2, "decimal");
        
    end
end




