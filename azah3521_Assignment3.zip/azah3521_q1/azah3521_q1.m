% ENG1802 Assignment 3 - Question 1 a)
% To create a function that takes an image and cropping
% Dimensions as parameters
% 
% Author: ABBAS ZAHR
% This code will test the image_crop function using image2
% 
% Start with a clear workspace and close all tabs

clear;
clc;
close all

% Create a variable named pic which takes the name of the image file to be
% passed onto the function.
pic = 'image2.jpg';

% Now create an array representing the size and position of the crop 
% rectangle in spatial coordinates, this contains:
% 
%          minimum X
%          minimum Y
%          Width
%          Height 
% 
y = [585 845 239 129];

% Now call the function image_crop in which takes these two arrays as
% inputs.
cropped_image = image_crop(pic, y);

% Show the cropped image
imshow(cropped_image)

% Write the cropped image into a JPG format with the name azah3521_q1answer  
imwrite(cropped_image, 'azah3521_q1answer.jpg')