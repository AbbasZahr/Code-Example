% ENG1802 Assignment 3 - Question 2 a)
% 
% Write a function that takes an array, counts the frequency of occurrence
% for each value and returns a two-column array. For example, the
% image1.jpg will be read into the code and passed into the function as an
% array. Then each intensity value 0-255 will be counted and the frequency
% will be a final 256x2 output containing the frequencies,
% 
% Author: ABBAS ZAHR
% SID   : 500548943  

% Create a function named im_histogram and takes pic as a parameter
function freq_count = im_histogram(pic)

% obtain the size of the image parameter
[rows, cols, colors] = size(pic);

% Create a transposed zero array composed of one column containing the
% numbers from 0 to 255, and another column containing zeros only
freq_count = [0:255;zeros(1,256)]'; 

% loop through the freq_count array
for j = 1:colors
    for r = 1:rows
        for c = 1:cols
          
%           For when the array is true color, the pixel values are
%           increased. Count each element in the array and return the final
%           output array
            freq_count(pic(r,c,j)+1, 2) = freq_count(pic(r,c,j)+1,2) + 1;
         
        end
    end
end

end