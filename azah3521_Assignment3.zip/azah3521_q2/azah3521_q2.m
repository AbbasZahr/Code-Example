% ENG1802 Assignment 3 - Question 2 b)
% To create a code that tests the function im_histogram created in question
% 1. It will include 4 histograms based on image1
% 
% Author: ABBAS ZAHR
% SID   : 500548943  
% 
% Start witha clear workspace and command window
clear
clc
close all

% Read the 'image.jpg' file and initialise it to a variable named pic
pic = imread('image1.jpg');

% Call the function for each colour channel of the image as well as for the
% image containing all 3 colour channels
red_channel = im_histogram(pic(:,:,1));

green_channel = im_histogram(pic(:, :, 2));

blue_channel = im_histogram(pic(:,:,3));

all_channels = im_histogram(pic);

% Create a 2x2 subplot and plot each channel using the bar function
% Label each bar graph respective to the colour channel and include 
% axis labels and legends
% 
% Bar graph for the red channel
subplot(2,2,1)
bar(red_channel, 'r')
axis([0 255 0 12000])
xlabel('Intensity Value')
ylabel('Count')
legend('Red Channel', 'Location', 'northwest')

% Bar graph for the green channel
subplot(2,2,2)
bar(green_channel, 'g')
axis([0 255 0 2.5*10^4])
xlabel('Intensity Value')
ylabel('Count')
legend('Green Channel', 'Location', 'northwest')

% Bar graph for the blue channel
subplot(2,2,3)
bar(blue_channel, 'b')
axis([0 255 0 2.5*10^4])
xlabel('Intensity Value')
ylabel('Count')
legend('Blue Channel', 'Location', 'northwest')

% Bar graph for all channels
subplot(2,2,4)
bar(all_channels, 'black')
axis([0 255 0 4*10^4])
xlabel('Intensity Value')
ylabel('Count')
legend('All Channels', 'Location', 'northwest')

% Store the figure as a variable
azah3521_q2answer = figure(1);

% Use the saveas function to store all the plotted data into one figure
% file format.
saveas(azah3521_q2answer, 'azah3521_q2answer', 'jpg');


